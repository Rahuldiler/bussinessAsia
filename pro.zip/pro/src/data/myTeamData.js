export const myTeamData = [
    {
      id: "1",
      img: "/img/team-1.jpeg",
      name: "Alexa Liras",
      email: "alexa@creative-tim.com",
      job: ["Programator", "Developer"],
    },
    {
      id: "2",
      img: "/img/team-1.jpeg",
      name: "Alexa Liras",
      email: "alexa@creative-tim.com",
      job: ["Programator", "Developer"],
    },
{
      id: "3",
      img: "/img/team-1.jpeg",
      name: "Alexa Liras",
      email: "alexa@creative-tim.com",
      job: ["Programator", "Developer"],
    },
{
      id: "4",
      img: "/img/team-1.jpeg",
      name: "Alexa Liras",
      email: "alexa@creative-tim.com",
      job: ["Programator", "Developer"],
    },
    {
      id: "2",
      img: "/img/team-1.jpeg",
      name: "Alexa Liras",
      email: "alexa@creative-tim.com",
      job: ["Programator", "Developer"],
    },
{
      id: "2",
      img: "/img/team-1.jpeg",
      name: "Alexa Liras",
      email: "alexa@creative-tim.com",
      job: ["Programator", "Developer"],
    },
  ];
  
  export default myTeamData;