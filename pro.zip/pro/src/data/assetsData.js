export const assetsData = [

    {
      id: 1,
      img: "/img/team-2.jpeg",
      name: "John Michael",
      description: "lorem ipsum dolor sit amet, consectetur adip",
      value: "2,000",
      category: "category",
      date: "23/04/18",
    },
    {
      id: 2,
      img: "/img/team-2.jpeg",
      name: "John Michael",
      description: "lorem ipsum dolor sit amet, consectetur adip",
      value: "2,000",
      category: "category",
      date: "23/04/18",
    },
    {
      id: 3,
      img: "/img/team-2.jpeg",
      name: "John Michael",
      description: "lorem ipsum dolor sit amet, consectetur adip",
      value: "2,000",
      category: "category",
      date: "23/04/18",
    },
    {
      id: 4,
      img: "/img/team-2.jpeg",
      name: "John Michael",
      description: "lorem ipsum dolor sit amet, consectetur adip",
      value: "2,000",
      category: "category",
      date: "23/04/18",
    },
    {
      id: 5,
      img: "/img/team-2.jpeg",
      name: "John Michael",
      description: "lorem ipsum dolor sit amet, consectetur adip",
      value: "2,000",
      category: "category",
      date: "23/04/18",
    },
    {
      id: 6,
      img: "/img/team-2.jpeg",
      name: "John Michael",
      description: "lorem ipsum dolor sit amet, consectetur adip",
      value: "2,000",
      category: "category",
      date: "23/04/18",
    },
 
  ];
  
  export default assetsData;